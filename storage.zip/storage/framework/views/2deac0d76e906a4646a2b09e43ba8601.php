<!DOCTYPE html>
<html>
<head>
    <title>Import Mahasiswa</title>
</head>
<body>
    <h1>Import Mahasiswa</h1>

    <?php if($errors->any()): ?>
        <div>
            <h3>Errors:</h3>
            <ul>
                <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>Row <?php echo e($error['row']); ?>: <?php echo e(implode(', ', $error['errors'])); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div>
            <strong><?php echo e(session('success')); ?></strong>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="file" required>
        <button type="submit">Import</button>
    </form>
</body>
</html>
<?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/import.blade.php ENDPATH**/ ?>