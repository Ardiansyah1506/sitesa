<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php
      $cards = [
        ['icon' => 'fa-users', 'iconColor' => 'success', 'category' => 'Mahasiswa', 'value' => $mhs, 'moreInfo' => route('admin.mahasiswa'),'backgroundClass'=> ''],
        ['icon' => 'fa-user-friends', 'iconColor' => 'success', 'category' => 'Dosen Pembimbing', 'value' => $dosbim, 'moreInfo' => route('admin.dosen.listDosen'),'backgroundClass'=> 'bg-secondary'],
        ['icon' => 'fa-book-reader', 'iconColor' => 'success', 'category' => 'Judul', 'value' => $judul,  'moreInfo'=> route('admin.tesis.index'),'backgroundClass'=> 'bg-warning'],
        ['icon' => 'fa-calendar-alt', 'iconColor' => 'success', 'category' => 'Daftar TA', 'value' => $ta, 'moreInfo' => route('admin.ta.index'),'backgroundClass'=> 'bg-success'],
        ['icon' => 'far fa-list-alt', 'iconColor' => 'success', 'category' => 'Akademik', 'value' => 5, 'moreInfo' => route('index-surat'),'backgroundClass'=> 'bg-info'],
        ['icon' => 'fa-user-tie', 'iconColor' => 'success', 'category' => 'Dosen', 'value' => $dosen,  'moreInfo'=> route('admin.dosen.listDosen'),'backgroundClass'=> 'bg-success'],
      ];
    ?> 
    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if (isset($component)) { $__componentOriginal010ba8afce9cba59c24d9c0985e54786 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal010ba8afce9cba59c24d9c0985e54786 = $attributes; } ?>
<?php $component = App\View\Components\admin\cardDashboard::resolve(['icon' => $card['icon'],'iconColor' => $card['iconColor'],'category' => $card['category'],'value' => $card['value'],'moreInfo' => $card['moreInfo'],'backgroundClass' => $card['backgroundClass']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\admin\cardDashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal010ba8afce9cba59c24d9c0985e54786)): ?>
<?php $attributes = $__attributesOriginal010ba8afce9cba59c24d9c0985e54786; ?>
<?php unset($__attributesOriginal010ba8afce9cba59c24d9c0985e54786); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal010ba8afce9cba59c24d9c0985e54786)): ?>
<?php $component = $__componentOriginal010ba8afce9cba59c24d9c0985e54786; ?>
<?php unset($__componentOriginal010ba8afce9cba59c24d9c0985e54786); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/admin/index.blade.php ENDPATH**/ ?>