<!DOCTYPE html>
<html lang="en">
  <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <?php echo $__env->yieldContent('css-library'); ?>
  <?php echo $__env->yieldContent('css-custom'); ?>
  <body>
    <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="wrapper d-flex justify-content-center align-items-center bg-cuy">
        <div class="container">
          <div class="page-inner">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>
    </div>
    <?php echo $__env->yieldContent('js-library'); ?>
    <?php echo $__env->yieldContent('js-custom'); ?>
  </body>
</html>
<?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/auth/main-auth.blade.php ENDPATH**/ ?>