<?php $__env->startSection('content'); ?>
<div class="row">
   <p>Dokumen Proposal</p>
   <a href="<?php echo e(asset('storage/dokumen/proposalPAI2023.pdf')); ?>" target="_blank">Unduh Dokumen Proposal</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/mhs/akademik/index.blade.php ENDPATH**/ ?>