<li class="nav-item  <?php if($active == 'home-mhs'): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('mhs.index')); ?>">
      <i class="fas fa-home"></i>
      <p class="text-white">Dashboard</p>
    </a>
</li>
<li class="nav-item <?php if($active == 'pembimbing-mhs'): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('mhs.pembimbing.index')); ?>">
      <i class="icon-people"></i>
      <p class="text-white">Pengajuan Pembimbing</p>
    </a>
</li>
<li class="nav-item <?php if($active == 'bimbingan-mhs'): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('mhs.bimbingan.index')); ?>">
      <i class="icon-user-following"></i>
      <p class="text-white">Bimbingan</p>
    </a>
</li>
<li class="nav-item <?php if($active == 'ta-mhs'): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('mhs.ta.waktu')); ?>">
      <i class="icon-user-following"></i>
      <p class="text-white">Sidang TA</p>
    </a>
</li>
<li class="nav-item <?php if($active == 'Akademik'): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('index-surat')); ?>">
      <i class="icon-user-following"></i>
      <p class="text-white">Informasi Akademik</p>
    </a>
</li><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/sidebar/sidebar-mhs.blade.php ENDPATH**/ ?>