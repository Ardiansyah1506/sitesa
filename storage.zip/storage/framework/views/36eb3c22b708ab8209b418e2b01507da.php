<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo e($title); ?> - Sistem Informasi Tesis Aswaja</title>
    <meta
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
      name="viewport"
    />
    <link
      rel="icon"
      href="<?php echo e(url('')); ?>/assets/img/icon-unwahas.png"
      type="image/x-icon"
    />

    <!-- Fonts and icons -->
    <script src="<?php echo e(url('')); ?>/assets/js/plugin/webfont/webfont.min.js"></script>
    
  
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["<?php echo e(url('')); ?>/assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/css/kaiadmin.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/css/style.css" />
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/css/styles.css" />

  </head><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/header.blade.php ENDPATH**/ ?>