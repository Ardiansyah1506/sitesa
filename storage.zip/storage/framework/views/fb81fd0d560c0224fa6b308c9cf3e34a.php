<!-- Modal Upload Bab 1 -->
<div class="modal fade" id="bab1Modal" tabindex="-1" aria-labelledby="bab1ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="bab1ModalLabel">Upload File Bab 1</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="uploadFormBab1" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="file">Pilih File</label>
                        <input type="file" name="file" id="file" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php for($i = 2; $i <= 6; $i++): ?>
<!-- Modal Upload Bab <?php echo e($i); ?> -->
<div class="modal fade" id="bab<?php echo e($i); ?>Modal" tabindex="-1" aria-labelledby="bab<?php echo e($i); ?>ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="bab<?php echo e($i); ?>ModalLabel">Upload File Bab <?php echo e($i); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="uploadFormBab<?php echo e($i); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="file">Pilih File</label>
                        <input type="file" name="file" id="file" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endfor; ?>
<?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/mhs/bimbingan/modal.blade.php ENDPATH**/ ?>