<div class="modal fade" id="modalEditBimbingan" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Pembimbing</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('prodi.update-bimbingan')); ?>" method="POST" id="formEditBimbingan">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <input type="hidden" id="id-edit-mhs" name="nim">
                    <div class="form-group">
                        <label for="nama-mahasiswa">Nama Mahasiswa</label>
                        <input type="text" id="nama-mahasiswa" class="form-control" name="nama" readonly>
                    </div>
                    <div class="form-group">
                        <label for="pembimbing-1">Pembimbing Pertama</label>
                        <select class="form-select mb-2" aria-label="Pembimbing 1" id="pembimbing-1" name="pembimbing1">
                            <?php $__currentLoopData = $pembimbing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bimbing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bimbing->nip); ?>"><?php echo e($bimbing->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="pembimbing-2">Pembimbing Kedua</label>
                        <select class="form-select mb-2" aria-label="Pembimbing 1" id="pembimbing-2" name="pembimbing2">
                            <?php $__currentLoopData = $pembimbing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bimbing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bimbing->nip); ?>"><?php echo e($bimbing->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>   
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/prodi/bimbingan/modal.blade.php ENDPATH**/ ?>