<div class="sidebar bg-sidebar">
    <div class="sidebar-wrapper scrollbar scrollbar-inner bg-sidebar">
      <div class="text-dark text-center py-5 px-3 ">
        <a class="dropdown-item btn py-2 btn-danger" href="<?php echo e(route('logout')); ?>"><i class="icon-power mr-4"></i> Logout</a>
         
      </div>
    
      <div class="sidebar-content">
        <ul class="nav nav-secondary text-dark">
            <?php if(auth()->user()->role == 1): ?>
              <?php echo $__env->make('layout.sidebar.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(auth()->user()->role == 2): ?>
              <?php echo $__env->make('layout.sidebar.sidebar-prodi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(auth()->user()->role == 3): ?>
              <?php echo $__env->make('layout.sidebar.sidebar-dosbim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(auth()->user()->role == 4): ?>
              <?php echo $__env->make('layout.sidebar.sidebar-mhs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </ul>
      </div>
    </div>
  </div><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/sidebar.blade.php ENDPATH**/ ?>