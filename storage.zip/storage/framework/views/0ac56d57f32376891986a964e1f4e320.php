<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Detail Bimbingan | <?php echo e($nama); ?></h4>
        </div>
        <div class="card-body">
            <h3 class="fw-bold mb-3 py-4">Judul : <?php echo e($tesis->judul); ?></h3>
            <div class="tab-content mt-2 mb-3" id="pills-without-border-tabContent">
                <?php $__currentLoopData = range(1, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $babVar = 'bab' . $i;
                    ?>

                    <?php if(isset($$babVar)): ?>
                        <div class="col-sm-6 col-md-3 mt-3">
                            <div class="card card-stats card-info card-round mb-3">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-7 col-stats">
                                            <div class="numbers">
                                                <h4 class="card-title">BAB <?php echo e($i); ?></h4>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="icon-big text-center">
                                                <?php if($$babVar->status == 1): ?>
                                                    <i class="icon-check"></i>
                                                <?php else: ?>
                                                    <a href="<?php echo e(asset("bab$i/" . $$babVar->nama_file)); ?>">
                                                        <i class="fas fa-file-alt"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="button-bab-<?php echo e($i); ?> d-flex gap-3">
                                <?php if($$babVar->status == 1): ?>
                                    <button class="btn btn-primary" style="display: none" id="btn-revisi-bab-<?php echo e($i); ?>"> <i class="fas fa-clock"></i> Revisi</button>
                                <?php elseif($$babVar->status == 2): ?>
                                    <p class="my-auto"><span class="badge badge-warning">Catatan revisi terkirim</span></p>
                                <?php else: ?>
                                    <button class="btn btn-primary" id="btn-revisi-bab-<?php echo e($i); ?>"> <i class="fas fa-clock"></i> Revisi</button>
                                <?php endif; ?>

                                <form action="<?php echo e($$babVar->status == 1 || $$babVar->status == 2 ? '#' : route('dosbim.acc-bab')); ?>" method="POST" id="acc-bab-<?php echo e($i); ?>" style="<?php echo e($$babVar->status == 1 || $$babVar->status == 2 ? 'display: none' : ''); ?>">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="text" value="<?php echo e($nim); ?>" name="nim" hidden>
                                    <input type="text" value="<?php echo e($$babVar->id_kategori); ?>" name="babKe" hidden>
                                    <button type="submit" class="btn btn-success"> <i class="fas fa-check"></i> Acc</button>
                                </form>
                            </div>
                            <div class="formBab<?php echo e($i); ?>" style="display: none">
                                <form action="<?php echo e(route("dosbim.store-catatan-bab-$i")); ?>" class="d-flex" id="catatan-bab-<?php echo e($i); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="bab-<?php echo e($i); ?>">Catatan</label>
                                        <input type="text" value="<?php echo e($nim); ?>" name="nim" hidden>
                                        <input type="text" name="catatan" class="form-control" id="bab-<?php echo e($i); ?>" aria-describedby="catatan" placeholder="Masukkan Catatan" required>
                                    </div>
                                    <button type="submit" class="btn my-auto btn-primary">Kirim</button>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <p>
                            <span class="badge badge-danger mt-5">Bab <?php echo e($i); ?> belum di upload</span>
                        </p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-custom'); ?>
<script>
    $(document).ready(function(){
        <?php $__currentLoopData = range(1, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $('#btn-revisi-bab-<?php echo e($i); ?>').on('click', function(){
                $('.formBab<?php echo e($i); ?>').toggle(); // Use class selector and toggle() to show/hide
            });
            $('#acc-bab-<?php echo e($i); ?>').on('submit', function(event) {
                event.preventDefault(); // Prevent default form submission

                // JavaScript confirm dialog
                if (confirm('Acc Pengajuan mahasiswa Bab ke <?php echo e($i); ?>?')) {
                    // If user confirms, submit the form
                    $(this)[0].submit();
                } else {
                    // If user cancels, show an alert
                    alert('Batal Acc Mahasiswa');
                }
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/dosbim/bimbingan/detail.blade.php ENDPATH**/ ?>