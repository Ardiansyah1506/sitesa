
<div class="col-sm-6 col-md-3">
    <div class="card card-stats <?php echo e($backgroundClass); ?>">
      <div class="card-body">
        <div class="row align-items-center">
          <div class="col-icon">
            <div class="icon-big text-center icon-<?php echo e($iconColor); ?> bubble-shadow-small">
              <i class="fas <?php echo e($icon); ?>"></i>
            </div>
          </div>
          <div class="col ms-3 ms-sm-0">
            <div class="numbers">
              <p class="card-category"><?php echo e($category); ?></p>
              <h4 class="card-title"><?php echo e($value); ?></h4>
            </div>
        </div>
        <div class="d-flex justify-content-end">
          <a href="<?php echo e($moreInfo); ?>">more info</a>
        </div>
        </div>
      </div>
    </div>
  </div>
  <?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/components/admin/card-dashboard-admin.blade.php ENDPATH**/ ?>