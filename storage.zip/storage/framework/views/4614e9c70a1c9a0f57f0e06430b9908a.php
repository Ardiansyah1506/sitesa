<li class="nav-item active">
    <a data-bs-toggle="collapse" href="#bimbingan">
      <i class="fas fa-layer-group"></i>
      <p class="text-white">Bimbingan</p>
      <span class="caret"></span>
    </a>
    <div class="collapse" id="bimbingan">
      <ul class="nav nav-collapse">
        <li class=" <?php if($active == 'bimbingan'): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('dosbim.bimbingan')); ?>">
            <span class="sub-item text-white">Mahasiswa Bimbingan</span>
          </a>
        </li>
        <li class=" <?php if($active == 'pengajuan'): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('dosbim.pengajuan')); ?>">
            <span class="sub-item text-white">Pengajuan Bimbingan</span>
          </a>
        </li>
      </ul>
    </div>
  </li><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/sidebar/sidebar-dosbim.blade.php ENDPATH**/ ?>