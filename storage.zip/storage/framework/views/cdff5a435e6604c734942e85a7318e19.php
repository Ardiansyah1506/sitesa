<li class="nav-item <?php if($active == 'admin-dashboard'): ?> active <?php endif; ?>">
  <a href="<?php echo e(route('admin.index')); ?>">
    <i class="fas fa-home"></i>
    <p class="text-white">Dashboard</p>
  </a>
</li>
<li class="nav-item <?php if($active == 'admin-user'): ?> active <?php endif; ?>">
  <a href="<?php echo e(route('admin.user.index')); ?>">
    <i class="icon-user"></i>
    <p class="text-white">User</p>
  </a>
</li>
<li class="nav-item <?php if($active == 'admin-tesis'): ?> active <?php endif; ?>">
  <a href="<?php echo e(route('admin.tesis.index')); ?>">
    <i class="icon-envelope"></i>
    <p class="text-white">Tesis</p>
  </a>
</li>
<li class="nav-item <?php if($active == 'admin-ta'): ?> active <?php endif; ?>">
  <a href="<?php echo e(route('admin.ta.index')); ?>">
    <i class="icon-book-open"></i>
    <p class="text-white">Tugas Akhir</p>
  </a>
</li>
<li class="nav-item <?php if($active == 'admin-mahasiswa' || $active == 'admin-pengajuan'): ?> active <?php endif; ?>">
  <a
    data-bs-toggle="collapse"
    href="#dashboard"
    class="collapsed"
    aria-expanded="false"
  >
    <i class="fas fa-user-tie"></i>
    <p class="text-white">Mahasiswa</p>
    <span class="caret"></span>
  </a>
  <div class="collapse" id="dashboard">
    <ul class="nav nav-collapse">
      <li class="nav-item <?php if($active == 'admin-mahasiswa'): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('admin.mahasiswa')); ?>">
          <i class="icon-people"></i>
          <p class="text-white">Daftar Mahasiswa</p>
        </a>
      </li>
      <li class="nav-item <?php if($active == 'admin-pengajuan'): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('admin.pengajuan')); ?>">
          <i class="icon-arrow-up-circle"></i>
          <p class="text-white">Pengajuan Bimbingan</p>
        </a>
      </li>
    </ul>
  </div>
</li>
<li class="nav-item <?php if($active == 'Dosen Pembimbing'): ?> active <?php endif; ?>">
  <a
    data-bs-toggle="collapse"
    href="#dosen"
    class="collapsed"
    aria-expanded="false"
  >
    <i class="fas fa-user-tie"></i>
    <p class="text-white">Dosen Pembimbing</p>
    <span class="caret"></span>
  </a>
  <div class="collapse" id="dosen">
    <ul class="nav nav-collapse">
      <li class="nav-item <?php if($active == 'admin-pengajuan-pembimbing'): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('admin.dosen.index')); ?>">
          <i class="icon-people"></i>
          <p class="text-white">Pengajuan</p>
        </a>
      </li>
      <li class="nav-item <?php if($active == 'list-dosen'): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('admin.dosen.listDosen')); ?>">
          <i class="icon-arrow-up-circle"></i>
          <p class="text-white">List</p>
        </a>
      </li>
    </ul>
  </div>
</li>
<?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/sidebar/sidebar-admin.blade.php ENDPATH**/ ?>