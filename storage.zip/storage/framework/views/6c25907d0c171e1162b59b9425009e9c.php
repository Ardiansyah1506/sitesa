<nav class="navbar navbar-header px-3 border-none bg-navbar navbar-expand-lg">
    <div class="container-fluid">
      <nav
        class="navbar navbar-header-left navbar-expand-lg navbar-form nav-search p-0 d-none d-lg-flex"
      >
        <img src="<?php echo e(asset('assets/img/logo-program-pascasarjana.png')); ?>" alt="" height="60">
      </nav>

      <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
        <li class="nav-item topbar-user dropdown hidden-caret">
          <img
            src="<?php echo e(asset('assets/img/logo-unwahas.png')); ?>"
            alt="navbar brand"
            class="navbar-brand"
            height="60"
          />
        </li>
        
      </ul>
    </div>
  </nav><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/navbar.blade.php ENDPATH**/ ?>