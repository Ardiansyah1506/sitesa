<li class="nav-item <?php if($active == "dashboard"): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('prodi.index')); ?>">
      <i class="fas fa-home"></i>
      <p class="text-white">Dashboard</p>
    </a>
  </li>

  <li class="nav-item <?php if($active == "pengajuan-prodi" || $active == "bimbingan-langsung"): ?> active <?php endif; ?>">
    <a data-bs-toggle="collapse" href="#bimbingan">
      <i class="icon-people"></i>
      <p class="text-white">Bimbingan</p>
      <span class="caret"></span>
    </a>
    <div class="collapse" id="bimbingan">
      <ul class="nav nav-collapse">
        <li class="<?php if($active == "pengajuan-prodi"): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('prodi.pengajuan')); ?>">
            <span class="sub-item text-white">Pengajuan Pembimbing</span>
          </a>
        </li>
        <li class="<?php if($active == "bimbingan-langsung"): ?> active <?php endif; ?>">
          <a href="<?php echo e(route('prodi.bimbingan')); ?>">
            <span class="sub-item text-white">Sedang Bimbingan</span>
          </a>
        </li>
      </ul>
    </div>
  </li>

  <li class="nav-item <?php if($active == "waktu-ta"): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('prodi.waktu-ta')); ?>">
      <i class="icon-hourglass"></i>
      <p class="text-white">Waktu TA</p>
    </a>
  </li>

  <li class="nav-item <?php if($active == "kuota-pembimbing"): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('prodi.kuota-pembimbing')); ?>">
      <i class="icon-calculator"></i>
      <p class="text-white">Kuota Pembimbing</p>
    </a>
  </li>

  <li class="nav-item <?php if($active == "Dosen"): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('prodi.dosen.index')); ?>">
      <i class="icon-user-following"></i>
      <p class="text-white">Dosen Pembimbing</p>
    </a>
  </li>

  <li class="nav-item <?php if($active == "tesis"): ?> active <?php endif; ?>">
    <a href="<?php echo e(route('prodi.verif-tesis.index')); ?>">
      <i class="icon-user-following"></i>
      <p class="text-white">Tesis</p>
    </a>
  </li><?php /**PATH /home/ziiardiansyah/Documents/Psiudinus/sitesa-dev/sitesa/resources/views/layout/sidebar/sidebar-prodi.blade.php ENDPATH**/ ?>